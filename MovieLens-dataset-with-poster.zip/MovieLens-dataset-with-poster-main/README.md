# MovieLens-dataset-with-poster
MovieLens dataset with poster and introduction
